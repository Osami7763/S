import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createAssignment, createLesson, createScheduleItem, createSchoolUser, createSubject, deleteAssignment, deleteLesson, deleteScheduleItem, deleteSubject, getUserByUsername, listSchoolContent, listSchoolUsers, updateAssignment, updateLesson, updateScheduleItem, updateSubject } from "./db";
import { storagePut } from "./storage";
import { createSchoolToken, hashPassword, SCHOOL_COOKIE, schoolCookieOptions, verifyPassword } from "./school-auth";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

const schoolManagerProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "manager" && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "هذه العملية متاحة لمدير المدرسة فقط" });
  return next({ ctx });
});
const schoolLoginInput = z.object({ username: z.string().trim().min(1).max(64), password: z.string().min(1).max(128) });
const createUserInput = z.object({ username: z.string().trim().min(1).max(64).regex(/^[0-9A-Za-z_-]+$/), password: z.string().min(1).max(128), name: z.string().trim().min(2).max(120), role: z.enum(["teacher", "student", "parent"]) });
const subjectInput = z.object({ name: z.string().trim().min(2).max(120), color: z.string().max(24).default("teal") });
const lessonInput = z.object({ subjectId: z.number().int().positive(), title: z.string().trim().min(2).max(180), lessonDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), page: z.string().max(80).optional(), notes: z.string().max(5000).optional() });
const assignmentInput = z.object({ subjectId: z.number().int().positive(), title: z.string().trim().min(2).max(180), description: z.string().max(5000).optional(), dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), attachmentBase64: z.string().max(12_000_000).optional(), attachmentName: z.string().max(255).optional(), attachmentType: z.string().max(120).optional() });
const scheduleInput = z.object({ dayOfWeek: z.number().int().min(0).max(6), period: z.number().int().min(1).max(12), subjectId: z.number().int().positive(), startTime: z.string().max(10), endTime: z.string().max(10), room: z.string().max(80).optional() });
const idInput = z.object({ id: z.number().int().positive() });
const updateAssignmentInput = z.object({ id: z.number().int().positive(), title: z.string().trim().min(2).max(180), description: z.string().max(5000).optional(), dueDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) });
const updateLessonInput = z.object({ id: z.number().int().positive(), title: z.string().trim().min(2).max(180), lessonDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), page: z.string().max(80).optional(), notes: z.string().max(5000).optional() });
const updateSubjectInput = z.object({ id: z.number().int().positive(), name: z.string().trim().min(2).max(120), color: z.string().max(24), sortOrder: z.number().int().min(0).max(999) });
const updateScheduleInput = z.object({ id: z.number().int().positive(), dayOfWeek: z.number().int().min(0).max(6), period: z.number().int().min(1).max(12), subjectId: z.number().int().positive(), startTime: z.string().max(10), endTime: z.string().max(10), room: z.string().max(80).optional() });

type SchoolUser = import("../drizzle/schema").User;
function publicSchoolUser(user: SchoolUser) { return { id: user.id, username: user.username, name: user.name, email: user.email, role: user.role }; }

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user ? publicSchoolUser(ctx.user) : null),
    schoolLogin: publicProcedure.input(schoolLoginInput).mutation(async ({ input, ctx }) => {
      let user = await getUserByUsername(input.username);
      if (!user && input.username === "1" && input.password === "1") user = await createSchoolUser({ username: "1", passwordHash: hashPassword("1"), name: "مدير المدرسة", role: "manager" });
      if (!user || user.loginMethod !== "school" || !user.passwordHash || !verifyPassword(input.password, user.passwordHash)) throw new TRPCError({ code: "UNAUTHORIZED", message: "رقم المستخدم أو كلمة المرور غير صحيحة" });
      ctx.res.cookie(SCHOOL_COOKIE, await createSchoolToken(user.id), schoolCookieOptions());
      return publicSchoolUser(user);
    }),
    schoolLogout: publicProcedure.mutation(({ ctx }) => { ctx.res.clearCookie(SCHOOL_COOKIE, { ...schoolCookieOptions(), maxAge: 0 }); return { success: true } as const; }),
    logout: publicProcedure.mutation(({ ctx }) => { ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 }); ctx.res.clearCookie(SCHOOL_COOKIE, { ...schoolCookieOptions(), maxAge: 0 }); return { success: true } as const; }),
  }),
  school: router({
    content: publicProcedure.query(() => listSchoolContent()),
    users: schoolManagerProcedure.query(() => listSchoolUsers()),
    createUser: schoolManagerProcedure.input(createUserInput).mutation(async ({ input }) => {
      if (await getUserByUsername(input.username)) throw new TRPCError({ code: "CONFLICT", message: "رقم المستخدم مستخدم مسبقًا" });
      const user = await createSchoolUser({ username: input.username, passwordHash: hashPassword(input.password), name: input.name, role: input.role });
      if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "تعذر إنشاء الحساب" });
      return publicSchoolUser(user);
    }),
    createSubject: publicProcedure.input(subjectInput).mutation(({ input }) => createSubject(input)),
    createLesson: publicProcedure.input(lessonInput).mutation(({ input }) => createLesson(input)),
    createAssignment: publicProcedure.input(assignmentInput).mutation(async ({ input }) => { const { attachmentBase64, attachmentName, attachmentType, ...assignment } = input; if (!attachmentBase64) return createAssignment(assignment); const comma = attachmentBase64.indexOf(","); const raw = comma >= 0 ? attachmentBase64.slice(comma + 1) : attachmentBase64; const buffer = Buffer.from(raw, "base64"); if (buffer.length > 8 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "حجم المرفق يجب ألا يتجاوز 8 ميجابايت" }); const uploaded = await storagePut(`assignments/${Date.now()}-${attachmentName || "attachment"}`, buffer, attachmentType || "application/octet-stream"); return createAssignment({ ...assignment, attachmentUrl: uploaded.url, attachmentName }); }),
    createScheduleItem: publicProcedure.input(scheduleInput).mutation(({ input }) => createScheduleItem(input)),
    deleteAssignment: publicProcedure.input(idInput).mutation(({ input }) => deleteAssignment(input.id)),
    deleteLesson: publicProcedure.input(idInput).mutation(({ input }) => deleteLesson(input.id)),
    deleteScheduleItem: publicProcedure.input(idInput).mutation(({ input }) => deleteScheduleItem(input.id)),
    updateAssignment: publicProcedure.input(updateAssignmentInput).mutation(({ input }) => { const { id, ...values } = input; return updateAssignment(id, values); }),
    updateLesson: publicProcedure.input(updateLessonInput).mutation(({ input }) => { const { id, ...values } = input; return updateLesson(id, values); }),
    updateSubject: publicProcedure.input(updateSubjectInput).mutation(({ input }) => { const { id, ...values } = input; return updateSubject(id, values); }),
    deleteSubject: publicProcedure.input(idInput).mutation(({ input }) => deleteSubject(input.id)),
    updateScheduleItem: publicProcedure.input(updateScheduleInput).mutation(({ input }) => { const { id, ...values } = input; return updateScheduleItem(id, values); }),
  }),
});
export type AppRouter = typeof appRouter;
