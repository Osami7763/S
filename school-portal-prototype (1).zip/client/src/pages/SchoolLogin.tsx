import { useState } from "react";
import { GraduationCap, LockKeyhole, LogIn, ShieldCheck, UserRound } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function SchoolLogin() {
  const utils = trpc.useUtils();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const loginMutation = trpc.auth.schoolLogin.useMutation({
    onSuccess: async () => {
      setErrorMessage("");
      await utils.auth.me.invalidate();
    },
    onError: (error) => setErrorMessage(error.message || "تعذر تسجيل الدخول"),
  });

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage("");
    loginMutation.mutate({ username, password });
  };

  return (
    <main dir="rtl" className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#f6f8fb] px-4 py-8">
      <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-teal-200/30 blur-3xl" />
      <div className="absolute -bottom-32 -left-24 h-96 w-96 rounded-full bg-blue-200/30 blur-3xl" />
      <div className="relative grid w-full max-w-5xl overflow-hidden rounded-[32px] border border-slate-200/80 bg-white shadow-2xl shadow-slate-900/10 lg:grid-cols-[1.03fr_.97fr]">
        <section className="relative hidden overflow-hidden bg-slate-900 p-10 text-white lg:flex lg:flex-col lg:justify-between">
          <div className="absolute -left-24 -top-16 h-72 w-72 rounded-full bg-teal-500/20 blur-3xl" />
          <div className="absolute -bottom-24 right-1/3 h-72 w-72 rounded-full bg-blue-500/20 blur-3xl" />
          <div className="relative flex items-center gap-3"><div className="brand-mark flex h-12 w-12 items-center justify-center rounded-2xl shadow-lg shadow-teal-900/30"><GraduationCap className="h-6 w-6" /></div><div><p className="font-display text-xl font-bold">وصول</p><p className="text-[10px] font-semibold tracking-[0.2em] text-teal-300">منصة وصول</p></div></div>
          <div className="relative max-w-md"><div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-2 text-xs font-bold text-teal-200"><ShieldCheck className="h-4 w-4" /> نظام المدرسة الخاص</div><h1 className="font-display text-4xl font-bold leading-[1.25]">كل يوم دراسي،<br /><span className="text-teal-300">أوضح وأسهل.</span></h1><p className="mt-5 text-sm leading-8 text-slate-300">من الإدارة إلى الطالب، مساحة واحدة تساعد كل فرد في المدرسة على معرفة ما عليه فعله اليوم.</p></div>
          <p className="relative text-xs text-slate-400">بوابة داخلية مخصصة لمدرستك</p>
        </section>
        <section className="p-6 sm:p-10 lg:p-14">
          <div className="mb-9 lg:hidden"><div className="flex items-center gap-3"><div className="brand-mark flex h-11 w-11 items-center justify-center rounded-2xl text-white"><GraduationCap className="h-6 w-6" /></div><div><p className="font-display text-xl font-bold text-slate-900">وصول</p><p className="text-[10px] font-semibold tracking-[0.2em] text-teal-600">منصة وصول</p></div></div></div>
          <div className="max-w-sm"><p className="text-sm font-bold text-teal-600">مرحبًا بعودتك</p><h2 className="mt-2 font-display text-3xl font-bold tracking-tight text-slate-900">تسجيل الدخول</h2><p className="mt-3 text-sm leading-7 text-slate-500">أدخل رقم المستخدم وكلمة المرور للوصول إلى حسابك في نظام المدرسة.</p></div>
          <form onSubmit={submit} className="mt-9 max-w-sm space-y-5">
            <label className="block"><span className="mb-2.5 block text-sm font-bold text-slate-700">رقم المستخدم</span><div className="relative"><UserRound className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input autoComplete="username" inputMode="numeric" required value={username} onChange={(event) => setUsername(event.target.value)} placeholder="مثال: 1" className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50/50 pr-10 pl-4 text-sm outline-none transition focus:border-teal-400 focus:bg-white focus:ring-4 focus:ring-teal-500/10" /></div></label>
            <label className="block"><span className="mb-2.5 block text-sm font-bold text-slate-700">كلمة المرور</span><div className="relative"><LockKeyhole className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input autoComplete="current-password" required type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="أدخل كلمة المرور" className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50/50 pr-10 pl-4 text-sm outline-none transition focus:border-teal-400 focus:bg-white focus:ring-4 focus:ring-teal-500/10" /></div></label>
            {errorMessage && <p role="alert" className="rounded-xl border border-rose-100 bg-rose-50 px-3 py-2.5 text-xs font-semibold leading-5 text-rose-700">{errorMessage}</p>}
            <button disabled={loginMutation.isPending} className="button-lift flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-slate-900 text-sm font-bold text-white shadow-lg shadow-slate-900/15 transition hover:bg-teal-700 disabled:cursor-not-allowed disabled:opacity-60">{loginMutation.isPending ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" /> : <LogIn className="h-4 w-4" />} {loginMutation.isPending ? "جارٍ التحقق..." : "دخول إلى النظام"}</button>
          </form>
          <div className="mt-8 flex max-w-sm items-start gap-2.5 rounded-xl border border-slate-100 bg-slate-50 p-3.5 text-xs leading-6 text-slate-500"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal-600" /><span>الحسابات ينشئها مدير المدرسة فقط، وكل مستخدم يرى المعلومات المسموح بها لدوره.</span></div>
        </section>
      </div>
    </main>
  );
}
