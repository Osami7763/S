import { useMemo, useState } from "react";
import type { LucideIcon } from "lucide-react";
import {
  AlertCircle,
  ArrowUpLeft,
  BarChart3,
  Bell,
  BookOpen,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  CircleUserRound,
  ClipboardList,
  Clock3,
  Download,
  Eye,
  FileText,
  Filter,
  GraduationCap,
  LayoutDashboard,
  Megaphone,
  Menu,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  Sparkles,
  TrendingUp,
  Users,
  X,
} from "lucide-react";

type Section = "overview" | "courses" | "assignments" | "students" | "reports" | "announcements" | "calendar" | "settings";
type Role = "manager" | "teacher" | "student" | "parent";

type NavItem = {
  id: Section;
  label: string;
  icon: LucideIcon;
};

const navItems: NavItem[] = [
  { id: "overview", label: "نظرة عامة", icon: LayoutDashboard },
  { id: "courses", label: "المواد والدروس", icon: BookOpen },
  { id: "assignments", label: "الواجبات", icon: ClipboardList },
  { id: "students", label: "الطلاب والمعلمون", icon: Users },
  { id: "reports", label: "التقارير والتحليلات", icon: BarChart3 },
  { id: "announcements", label: "الإعلانات", icon: Megaphone },
  { id: "calendar", label: "التقويم المدرسي", icon: CalendarDays },
];

const roleOptions: { id: Role; label: string; shortLabel: string; color: string }[] = [
  { id: "manager", label: "المدير", shortLabel: "مدير المدرسة", color: "bg-blue-50 text-blue-700" },
  { id: "teacher", label: "المعلم", shortLabel: "معلم", color: "bg-violet-50 text-violet-700" },
  { id: "student", label: "الطالب", shortLabel: "طالب", color: "bg-amber-50 text-amber-700" },
  { id: "parent", label: "ولي الأمر", shortLabel: "ولي أمر", color: "bg-emerald-50 text-emerald-700" },
];

const roleContent: Record<Role, { greeting: string; subtitle: string; badge: string; focus: { label: string; value: string; note: string; icon: LucideIcon; tone: string }[] }> = {
  manager: {
    greeting: "صباح الخير، أستاذ أحمد",
    subtitle: "إليك ملخص أداء المدرسة اليوم. لديك 12 واجبًا يستحق المتابعة و3 إعلانات بانتظار النشر.",
    badge: "مركز قيادة المدرسة",
    focus: [
      { label: "تحتاج قرارًا", value: "7 طلبات", note: "طلبات بانتظار الاعتماد", icon: ClipboardList, tone: "amber" },
      { label: "تحتاج متابعة", value: "6 طلاب", note: "بسبب الغياب المتكرر", icon: AlertCircle, tone: "rose" },
      { label: "إجراء سريع", value: "نشر إعلان", note: "3 مسودات جاهزة", icon: Megaphone, tone: "teal" },
    ],
  },
  teacher: {
    greeting: "صباح الخير، أستاذ محمد",
    subtitle: "لديك 3 حصص اليوم و28 تسليمًا يحتاج مراجعة. ابدأ بأهم مهمة الآن.",
    badge: "مساحة المعلم اليومية",
    focus: [
      { label: "الحصة القادمة", value: "رياضيات 2", note: "الساعة 09:30 · ثاني ثانوي أ", icon: BookOpen, tone: "blue" },
      { label: "بانتظار التصحيح", value: "28 تسليمًا", note: "من 3 واجبات نشطة", icon: ClipboardList, tone: "violet" },
      { label: "إجراء سريع", value: "تسجيل حضور", note: "للحصة القادمة", icon: CheckCircle2, tone: "teal" },
    ],
  },
  student: {
    greeting: "أهلًا بك، يا عبدالله",
    subtitle: "لديك 4 مهام اليوم. أنجزت 72% من خطتك الأسبوعية، وبقيت خطوة واحدة على هدفك.",
    badge: "مساحتي الدراسية",
    focus: [
      { label: "الحصة القادمة", value: "الفيزياء 2", note: "الساعة 10:15 · معمل العلوم", icon: BookOpen, tone: "blue" },
      { label: "موعد قريب", value: "واجب الرياضيات", note: "يستحق غدًا 11:59 م", icon: Clock3, tone: "amber" },
      { label: "إنجاز الأسبوع", value: "72%", note: "أعلى من الأسبوع الماضي", icon: TrendingUp, tone: "emerald" },
    ],
  },
  parent: {
    greeting: "مرحبًا، أستاذة سارة",
    subtitle: "هذا ملخص ابنك عبدالله اليوم. لا توجد تنبيهات عاجلة، وهناك واجب واحد يحتاج متابعة.",
    badge: "متابعة الأبناء",
    focus: [
      { label: "الحضور اليوم", value: "حاضر", note: "وصل الساعة 07:42 ص", icon: CheckCircle2, tone: "emerald" },
      { label: "واجب قريب", value: "الرياضيات", note: "التسليم غدًا", icon: ClipboardList, tone: "amber" },
      { label: "رسالة المدرسة", value: "1 جديدة", note: "لقاء أولياء الأمور", icon: Bell, tone: "blue" },
    ],
  },
};

const stats = [
  { label: "إجمالي الطلاب", value: "1,248", note: "+8.2% هذا الشهر", icon: GraduationCap, tone: "blue" },
  { label: "المعلمون", value: "86", note: "4 طلبات انضمام", icon: Users, tone: "violet" },
  { label: "الواجبات النشطة", value: "32", note: "12 تستحق هذا الأسبوع", icon: ClipboardList, tone: "amber" },
  { label: "نسبة الحضور", value: "94.6%", note: "+2.4% عن الأسبوع الماضي", icon: TrendingUp, tone: "emerald" },
];

const subjects = [
  { name: "الرياضيات", teacher: "أ. محمد العتيبي", classes: "12 درسًا", progress: 78, color: "#2563eb", initials: "ر" },
  { name: "اللغة الإنجليزية", teacher: "أ. نورة الحربي", classes: "9 دروس", progress: 64, color: "#8b5cf6", initials: "EN" },
  { name: "الفيزياء", teacher: "أ. خالد المطيري", classes: "7 دروس", progress: 52, color: "#f59e0b", initials: "ف" },
  { name: "الكيمياء", teacher: "أ. سارة القحطاني", classes: "11 درسًا", progress: 86, color: "#10b981", initials: "ك" },
];

const assignments = [
  { title: "حل تمارين الفصل الثالث", subject: "رياضيات 2", className: "ثاني ثانوي / أ", due: "غدًا، 11:59 م", status: "قريب", statusTone: "amber", submitted: "28 / 32" },
  { title: "تقرير التجربة العملية", subject: "فيزياء 2", className: "ثاني ثانوي / ب", due: "20 سبتمبر", status: "مفتوح", statusTone: "blue", submitted: "19 / 30" },
  { title: "مراجعة المفردات", subject: "لغة إنجليزية", className: "أول ثانوي / أ", due: "22 سبتمبر", status: "مفتوح", statusTone: "blue", submitted: "24 / 28" },
];

const announcements = [
  { title: "لقاء أولياء الأمور", text: "نذكركم بموعد اللقاء التعريفي يوم الثلاثاء القادم في مسرح المدرسة.", date: "منذ ساعتين", tone: "blue" },
  { title: "تحديث جدول الاختبارات", text: "تم تحديث جدول اختبارات منتصف الفصل ويمكن الاطلاع عليه من التقويم.", date: "أمس", tone: "violet" },
  { title: "مسابقة الابتكار العلمي", text: "باب التسجيل مفتوح للطلاب الراغبين في المشاركة حتى نهاية الأسبوع.", date: "18 سبتمبر", tone: "amber" },
];

const toneStyles: Record<string, string> = {
  blue: "bg-blue-50 text-blue-700 border-blue-100",
  violet: "bg-violet-50 text-violet-700 border-violet-100",
  amber: "bg-amber-50 text-amber-700 border-amber-100",
  emerald: "bg-emerald-50 text-emerald-700 border-emerald-100",
};

function SectionHeading({ title, subtitle, action, onAction }: { title: string; subtitle: string; action?: string; onAction?: () => void }) {
  return (
    <div className="mb-6 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        <p className="mb-1 text-sm font-semibold text-teal-600">إدارة المدرسة / لوحة التحكم</p>
        <h1 className="font-display text-3xl font-bold tracking-tight text-slate-900">{title}</h1>
        <p className="mt-2 text-sm text-slate-500">{subtitle}</p>
      </div>
      {action && (
        <button onClick={onAction} className="button-lift inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-slate-900/15 hover:bg-teal-700">
          <Plus className="h-4 w-4" />
          {action}
        </button>
      )}
    </div>
  );
}

function EmptySection({ section, onAction }: { section: NavItem; onAction: () => void }) {
  const Icon = section.icon;
  return (
    <div className="animate-fade-up rounded-3xl border border-slate-200 bg-white p-10 text-center shadow-sm sm:p-16">
      <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-teal-50 text-teal-700">
        <Icon className="h-8 w-8" />
      </div>
      <h2 className="font-display text-2xl font-bold text-slate-900">{section.label}</h2>
      <p className="mx-auto mt-3 max-w-md text-sm leading-7 text-slate-500">هذه الشاشة جاهزة للربط بالبيانات الحقيقية. في النسخة الكاملة ستتمكن من إدارة هذا القسم من مكان واحد.</p>
      <button onClick={onAction} className="button-lift mt-7 inline-flex items-center gap-2 rounded-xl bg-teal-600 px-5 py-3 text-sm font-bold text-white hover:bg-teal-700">
        <Plus className="h-4 w-4" />
        إضافة أول عنصر
      </button>
    </div>
  );
}

export default function Home() {
  const [activeSection, setActiveSection] = useState<Section>("overview");
  const [activeRole, setActiveRole] = useState<Role>("manager");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState("");

  const activeNav = navItems.find((item) => item.id === activeSection) ?? navItems[0];

  const visibleSubjects = useMemo(() => subjects.filter((subject) => subject.name.includes(search) || subject.teacher.includes(search)), [search]);
  const currentRole = roleContent[activeRole];

  const selectSection = (section: Section) => {
    setActiveSection(section);
    setMobileOpen(false);
  };

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2600);
  };

  const renderOverview = () => (
    <div className="animate-fade-up space-y-6">
      <div className="flex flex-col justify-between gap-3 rounded-2xl border border-slate-200/80 bg-white p-4 shadow-sm sm:flex-row sm:items-center sm:px-5">
        <div><p className="text-sm font-bold text-slate-900">أنت تستخدم النظام كـ <span className="text-teal-700">{roleOptions.find((role) => role.id === activeRole)?.shortLabel}</span></p><p className="mt-1 text-xs text-slate-500">جرّب تبديل الدور لمعاينة التجربة التي سيحصل عليها كل فرد في المدرسة.</p></div>
        <div className="flex flex-wrap gap-1.5 rounded-xl bg-slate-50 p-1">{roleOptions.map((role) => <button key={role.id} onClick={() => setActiveRole(role.id)} className={`rounded-lg px-3 py-2 text-xs font-bold transition ${activeRole === role.id ? "bg-slate-900 text-white shadow-sm" : "text-slate-500 hover:bg-white hover:text-slate-800"}`}>{role.label}</button>)}</div>
      </div>
      <div className="relative overflow-hidden rounded-[28px] bg-slate-900 px-6 py-7 text-white shadow-xl shadow-slate-900/10 sm:px-9 sm:py-8">
        <div className="absolute -left-16 -top-24 h-64 w-64 rounded-full bg-teal-400/20 blur-3xl" />
        <div className="absolute bottom-0 right-1/3 h-40 w-40 rounded-full bg-blue-500/20 blur-3xl" />
        <div className="relative flex flex-col justify-between gap-7 md:flex-row md:items-center">
          <div className="max-w-xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1.5 text-xs font-semibold text-teal-100">
              <Sparkles className="h-3.5 w-3.5" />
              {currentRole.badge}
            </div>
            <h2 className="font-display text-2xl font-bold leading-tight sm:text-3xl">{currentRole.greeting} <span className="text-teal-300">.</span></h2>
            <p className="mt-3 max-w-lg text-sm leading-7 text-slate-300">{currentRole.subtitle}</p>
          </div>
          <div className="shrink-0 rounded-2xl border border-white/10 bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs text-slate-300">اليوم</p>
            <p className="mt-1 font-display text-xl font-bold">الأحد، 19 سبتمبر</p>
            <div className="mt-3 flex items-center gap-2 text-xs text-teal-200"><CalendarDays className="h-4 w-4" /> الأسبوع الدراسي الثالث</div>
          </div>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {currentRole.focus.map((item) => { const Icon = item.icon; return <button key={item.label} onClick={() => notify(`سيتم فتح: ${item.label}`)} className="card-hover flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-white p-4 text-right shadow-sm"><span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${item.tone === "rose" ? "border-rose-100 bg-rose-50 text-rose-700" : toneStyles[item.tone] ?? "border-teal-100 bg-teal-50 text-teal-700"}`}><Icon className="h-5 w-5" /></span><span className="min-w-0"><span className="block text-xs font-semibold text-slate-400">{item.label}</span><span className="mt-1 block truncate font-display text-base font-bold text-slate-900">{item.value}</span><span className="mt-1 block truncate text-[11px] text-slate-500">{item.note}</span></span><ArrowUpLeft className="mr-auto h-4 w-4 shrink-0 text-slate-300" /></button>; })}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="card-hover rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                  <p className="mt-2 font-display text-3xl font-bold tracking-tight text-slate-900">{stat.value}</p>
                </div>
                <span className={`flex h-11 w-11 items-center justify-center rounded-xl border ${toneStyles[stat.tone]}`}><Icon className="h-5 w-5" /></span>
              </div>
              <p className="mt-4 flex items-center gap-1.5 text-xs font-semibold text-emerald-600"><TrendingUp className="h-3.5 w-3.5" /> {stat.note}</p>
            </div>
          );
        })}
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.08fr_.92fr]">
        <section className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm sm:p-6">
          <div className="mb-6 flex items-center justify-between gap-4">
            <div><h2 className="font-display text-lg font-bold text-slate-900">تقدم المواد الدراسية</h2><p className="mt-1 text-xs text-slate-500">نسبة إكمال المحتوى خلال الفصل الدراسي</p></div>
            <button onClick={() => selectSection("courses")} className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:text-teal-900">عرض الكل <ArrowUpLeft className="h-3.5 w-3.5" /></button>
          </div>
          <div className="space-y-5">
            {subjects.map((subject) => (
              <div key={subject.name}>
                <div className="mb-2 flex items-center justify-between gap-3 text-sm">
                  <div className="flex min-w-0 items-center gap-3"><span style={{ backgroundColor: `${subject.color}18`, color: subject.color }} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-xs font-bold">{subject.initials}</span><div className="min-w-0"><p className="truncate font-bold text-slate-800">{subject.name}</p><p className="mt-0.5 truncate text-xs text-slate-400">{subject.teacher} · {subject.classes}</p></div></div>
                  <span className="font-display font-bold text-slate-700">{subject.progress}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100"><div style={{ width: `${subject.progress}%`, backgroundColor: subject.color }} className="h-full rounded-full transition-all duration-700" /></div>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm sm:p-6">
          <div className="mb-6 flex items-center justify-between gap-4"><div><h2 className="font-display text-lg font-bold text-slate-900">أحدث الإعلانات</h2><p className="mt-1 text-xs text-slate-500">آخر ما نُشر للمجتمع المدرسي</p></div><button onClick={() => selectSection("announcements")} className="text-xs font-bold text-teal-700 hover:text-teal-900">إدارة الإعلانات</button></div>
          <div className="space-y-3">
            {announcements.map((item) => (
              <div key={item.title} className="group flex gap-3 rounded-xl border border-slate-100 p-3.5 transition hover:border-teal-100 hover:bg-teal-50/40">
                <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border ${toneStyles[item.tone]}`}><Megaphone className="h-4 w-4" /></span>
                <div className="min-w-0"><div className="flex items-start justify-between gap-2"><h3 className="truncate text-sm font-bold text-slate-800">{item.title}</h3><span className="shrink-0 text-[10px] text-slate-400">{item.date}</span></div><p className="mt-1 line-clamp-2 text-xs leading-5 text-slate-500">{item.text}</p></div>
              </div>
            ))}
          </div>
          <button onClick={() => setShowCreate(true)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-slate-200 py-3 text-xs font-bold text-slate-500 transition hover:border-teal-300 hover:bg-teal-50 hover:text-teal-700"><Plus className="h-4 w-4" /> نشر إعلان جديد</button>
        </section>
      </div>

      <section className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm sm:p-6">
        <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><div><h2 className="font-display text-lg font-bold text-slate-900">الواجبات التي تحتاج متابعة</h2><p className="mt-1 text-xs text-slate-500">تابع التسليمات القادمة للمعلمين والطلاب</p></div><button onClick={() => selectSection("assignments")} className="inline-flex items-center gap-1 text-xs font-bold text-teal-700">كل الواجبات <ArrowUpLeft className="h-3.5 w-3.5" /></button></div>
        <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-right"><thead><tr className="border-b border-slate-100 text-xs text-slate-400"><th className="pb-3 font-medium">الواجب</th><th className="pb-3 font-medium">الفصل</th><th className="pb-3 font-medium">موعد التسليم</th><th className="pb-3 font-medium">التسليمات</th><th className="pb-3 font-medium">الحالة</th><th className="pb-3" /></tr></thead><tbody>{assignments.map((item) => <tr key={item.title} className="border-b border-slate-50 text-sm last:border-0"><td className="py-4"><p className="font-bold text-slate-800">{item.title}</p><p className="mt-1 text-xs text-slate-400">{item.subject}</p></td><td className="py-4 text-slate-600">{item.className}</td><td className="py-4"><span className="inline-flex items-center gap-1.5 text-xs text-slate-600"><Clock3 className="h-3.5 w-3.5 text-slate-400" />{item.due}</span></td><td className="py-4 font-display font-bold text-slate-700">{item.submitted}</td><td className="py-4"><span className={`rounded-full border px-2.5 py-1 text-[11px] font-bold ${toneStyles[item.statusTone]}`}>{item.status}</span></td><td className="py-4 text-left"><button onClick={() => notify("سيتم فتح تفاصيل الواجب في النسخة القادمة")} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-700"><MoreHorizontal className="h-4 w-4" /></button></td></tr>)}</tbody></table></div>
      </section>
    </div>
  );

  const renderCourses = () => (
    <div className="animate-fade-up">
      <SectionHeading title="المواد والدروس" subtitle="نظّم المحتوى التعليمي وتابع تقدم كل مادة." action="إضافة مادة" onAction={() => setShowCreate(true)} />
      <div className="mb-5 flex flex-col gap-3 sm:flex-row"><div className="relative flex-1"><Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث عن مادة أو معلم..." className="h-11 w-full rounded-xl border border-slate-200 bg-white pr-10 pl-4 text-sm outline-none transition focus:border-teal-400 focus:ring-4 focus:ring-teal-500/10" /></div><button className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-600 hover:border-teal-200 hover:text-teal-700"><Filter className="h-4 w-4" /> تصفية</button></div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{visibleSubjects.map((subject) => <div key={subject.name} className="card-hover overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm"><div className="h-2" style={{ backgroundColor: subject.color }} /><div className="p-5"><div className="flex items-start justify-between"><span style={{ backgroundColor: `${subject.color}18`, color: subject.color }} className="flex h-11 w-11 items-center justify-center rounded-xl font-bold">{subject.initials}</span><button className="text-slate-300 hover:text-slate-600"><MoreHorizontal className="h-5 w-5" /></button></div><h3 className="mt-5 font-display text-lg font-bold text-slate-900">{subject.name}</h3><p className="mt-1 text-xs text-slate-500">{subject.teacher}</p><div className="mt-5 flex items-center justify-between text-xs"><span className="text-slate-400">{subject.classes}</span><span className="font-bold text-slate-700">{subject.progress}% مكتمل</span></div><div className="mt-2 h-1.5 rounded-full bg-slate-100"><div style={{ width: `${subject.progress}%`, backgroundColor: subject.color }} className="h-full rounded-full" /></div><button onClick={() => notify(`تم فتح مادة ${subject.name}`)} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-slate-50 py-2.5 text-xs font-bold text-slate-600 hover:bg-teal-50 hover:text-teal-700"><Eye className="h-4 w-4" /> فتح المادة</button></div></div>)}</div>
    </div>
  );

  const renderSection = () => {
    if (activeSection === "overview") return renderOverview();
    if (activeSection === "courses") return renderCourses();
    return <><SectionHeading title={activeNav.label} subtitle="إدارة هذا القسم ومتابعة تفاصيله من لوحة واحدة." action="إضافة جديد" onAction={() => setShowCreate(true)} /><EmptySection section={activeNav} onAction={() => setShowCreate(true)} /></>;
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#f6f8fb] text-slate-900">
      <div className="flex min-h-screen">
        {mobileOpen && <button aria-label="إغلاق القائمة" onClick={() => setMobileOpen(false)} className="fixed inset-0 z-30 bg-slate-950/30 backdrop-blur-sm lg:hidden" />}
        <aside className={`fixed inset-y-0 right-0 z-40 flex w-[272px] flex-col border-l border-slate-200 bg-white px-4 py-5 shadow-2xl shadow-slate-900/10 transition-transform duration-300 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 lg:shadow-none ${mobileOpen ? "translate-x-0" : "translate-x-full"}`}>
          <div className="flex items-center justify-between px-3"><div className="flex items-center gap-3"><div className="brand-mark flex h-11 w-11 items-center justify-center rounded-2xl text-white shadow-lg shadow-teal-700/20"><GraduationCap className="h-6 w-6" /></div><div><p className="font-display text-lg font-bold tracking-tight text-slate-900">وصول</p><p className="text-[10px] font-semibold tracking-widest text-teal-600">منصة وصول</p></div></div><button onClick={() => setMobileOpen(false)} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 lg:hidden"><X className="h-5 w-5" /></button></div>
          <div className="my-8 h-px bg-slate-100" />
          <p className="px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">القائمة الرئيسية</p>
          <nav className="mt-3 space-y-1">{navItems.map((item) => { const Icon = item.icon; const active = activeSection === item.id; return <button key={item.id} onClick={() => selectSection(item.id)} className={`nav-item flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-semibold transition ${active ? "bg-teal-50 text-teal-700 shadow-sm shadow-teal-100" : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"}`}><Icon className={`h-[18px] w-[18px] ${active ? "text-teal-600" : "text-slate-400"}`} />{item.label}{item.id === "assignments" && <span className="mr-auto rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-700">12</span>}</button>; })}</nav>
          <div className="my-7 h-px bg-slate-100" /><p className="px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">النظام</p><nav className="mt-3"><button onClick={() => selectSection("settings")} className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-semibold transition ${activeSection === "settings" ? "bg-teal-50 text-teal-700" : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"}`}><Settings className="h-[18px] w-[18px] text-slate-400" />الإعدادات</button></nav>
          <div className="mt-auto rounded-2xl bg-slate-900 p-4 text-white"><div className="mb-3 flex items-center gap-2 text-teal-300"><Sparkles className="h-4 w-4" /><span className="text-xs font-bold">نسخة تجريبية</span></div><p className="text-xs leading-5 text-slate-300">هذه الواجهة نموذج أولي. سيتم ربطها بالحسابات والبيانات الحقيقية لاحقًا.</p><button onClick={() => notify("شكرًا! سنبدأ بتخصيص النظام لمدرستك")} className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-teal-500 py-2.5 text-xs font-bold text-white hover:bg-teal-400">تخصيص النظام <ArrowUpLeft className="h-3.5 w-3.5" /></button></div>
        </aside>

        <main className="min-w-0 flex-1">
          <header className="sticky top-0 z-20 border-b border-slate-200/70 bg-[#f6f8fb]/85 px-4 py-4 backdrop-blur-xl sm:px-6 lg:px-10"><div className="mx-auto flex max-w-[1440px] items-center justify-between gap-4"><div className="flex items-center gap-3"><button onClick={() => setMobileOpen(true)} className="rounded-xl border border-slate-200 bg-white p-2.5 text-slate-600 lg:hidden"><Menu className="h-5 w-5" /></button><div className="lg:hidden"><p className="font-display text-lg font-bold">وصول</p></div><div className="relative hidden w-72 md:block"><Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input placeholder="بحث سريع..." className="h-10 w-full rounded-xl border border-slate-200 bg-white/80 pr-10 pl-4 text-xs outline-none transition focus:border-teal-400 focus:ring-4 focus:ring-teal-500/10" /></div></div><div className="flex items-center gap-2 sm:gap-4"><button onClick={() => notify("لا توجد تنبيهات جديدة")} className="relative rounded-xl border border-slate-200 bg-white p-2.5 text-slate-500 hover:text-teal-700"><Bell className="h-[18px] w-[18px]" /><span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-[#f6f8fb] bg-rose-500" /></button><div className="hidden h-8 w-px bg-slate-200 sm:block" /><button className="flex items-center gap-2 rounded-xl p-1.5 text-right hover:bg-white"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-blue-600 text-sm font-bold text-white">أ</div><div className="hidden sm:block"><p className="text-xs font-bold text-slate-800">أحمد العبدالله</p><p className="mt-0.5 text-[10px] text-slate-400">مدير المدرسة</p></div><ChevronDown className="hidden h-4 w-4 text-slate-400 sm:block" /></button></div></div></header>
          <div className="mx-auto max-w-[1440px] px-4 py-7 sm:px-6 lg:px-10 lg:py-9">{renderSection()}</div>
        </main>
      </div>

      {showCreate && <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-sm"><div className="w-full max-w-md animate-fade-up rounded-3xl bg-white p-6 shadow-2xl"><div className="flex items-start justify-between"><div><p className="text-xs font-bold text-teal-600">إضافة عنصر جديد</p><h2 className="mt-1 font-display text-xl font-bold text-slate-900">إنشاء {activeSection === "announcements" ? "إعلان" : activeSection === "courses" ? "مادة" : "عنصر"}</h2></div><button onClick={() => setShowCreate(false)} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button></div><div className="mt-6 space-y-4"><label className="block"><span className="mb-2 block text-xs font-bold text-slate-600">العنوان</span><input placeholder="اكتب العنوان هنا" className="h-11 w-full rounded-xl border border-slate-200 px-3 text-sm outline-none focus:border-teal-400 focus:ring-4 focus:ring-teal-500/10" /></label><label className="block"><span className="mb-2 block text-xs font-bold text-slate-600">الوصف المختصر</span><textarea placeholder="أضف تفاصيل بسيطة..." className="h-24 w-full resize-none rounded-xl border border-slate-200 p-3 text-sm outline-none focus:border-teal-400 focus:ring-4 focus:ring-teal-500/10" /></label></div><div className="mt-6 flex gap-3"><button onClick={() => setShowCreate(false)} className="flex-1 rounded-xl border border-slate-200 py-3 text-sm font-bold text-slate-600 hover:bg-slate-50">إلغاء</button><button onClick={() => { setShowCreate(false); notify("تم حفظ العنصر في النسخة التجريبية"); }} className="flex-1 rounded-xl bg-teal-600 py-3 text-sm font-bold text-white hover:bg-teal-700">حفظ</button></div></div></div>}
      {toast && <div className="fixed bottom-5 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-xs font-bold text-white shadow-xl"><CheckCircle2 className="h-4 w-4 text-teal-300" />{toast}</div>}
    </div>
  );
}
